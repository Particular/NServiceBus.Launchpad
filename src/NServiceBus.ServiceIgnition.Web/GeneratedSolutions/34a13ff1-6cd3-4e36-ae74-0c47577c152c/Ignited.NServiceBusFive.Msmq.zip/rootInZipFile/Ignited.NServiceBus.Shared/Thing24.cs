using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class Thing24 : IMessage
    {
    }
}