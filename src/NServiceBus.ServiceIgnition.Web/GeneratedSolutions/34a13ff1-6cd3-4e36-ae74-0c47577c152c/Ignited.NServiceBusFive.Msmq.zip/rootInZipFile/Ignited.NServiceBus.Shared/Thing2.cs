using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class Thing2 : IMessage
    {
    }
}