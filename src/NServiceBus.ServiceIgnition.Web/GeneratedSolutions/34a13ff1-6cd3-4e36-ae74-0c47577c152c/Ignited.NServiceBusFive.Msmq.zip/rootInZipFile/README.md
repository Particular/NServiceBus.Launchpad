# Service Ignitor in Particular

### Instructions:
 - Open the Package Manager Console and run `Update-Package -Reinstall`
 - Build the solution
 - Enjoy