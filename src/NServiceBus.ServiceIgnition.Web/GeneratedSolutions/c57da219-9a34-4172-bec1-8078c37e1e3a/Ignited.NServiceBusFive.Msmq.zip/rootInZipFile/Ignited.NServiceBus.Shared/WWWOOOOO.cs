using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class WWWOOOOO : IMessage
    {
    }
}