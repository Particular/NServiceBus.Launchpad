using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class rgergergregr : IMessage
    {
    }
}