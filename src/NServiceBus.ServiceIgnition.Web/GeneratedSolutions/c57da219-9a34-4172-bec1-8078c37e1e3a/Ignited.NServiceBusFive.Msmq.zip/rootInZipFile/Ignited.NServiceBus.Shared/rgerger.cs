using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class rgerger : IMessage
    {
    }
}