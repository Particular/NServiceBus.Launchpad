using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class WWWOOOOOe3ww : IMessage
    {
    }
}