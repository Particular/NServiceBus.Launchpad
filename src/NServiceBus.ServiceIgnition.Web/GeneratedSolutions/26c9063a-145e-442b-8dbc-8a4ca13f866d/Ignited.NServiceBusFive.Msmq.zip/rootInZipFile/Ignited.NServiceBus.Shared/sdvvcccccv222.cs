using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class sdvvcccccv222 : IMessage
    {
    }
}