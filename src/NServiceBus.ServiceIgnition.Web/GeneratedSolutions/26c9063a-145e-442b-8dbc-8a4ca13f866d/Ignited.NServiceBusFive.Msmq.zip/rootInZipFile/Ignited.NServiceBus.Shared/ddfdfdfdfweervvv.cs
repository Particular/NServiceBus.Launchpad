using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class ddfdfdfdfweervvv : IMessage
    {
    }
}