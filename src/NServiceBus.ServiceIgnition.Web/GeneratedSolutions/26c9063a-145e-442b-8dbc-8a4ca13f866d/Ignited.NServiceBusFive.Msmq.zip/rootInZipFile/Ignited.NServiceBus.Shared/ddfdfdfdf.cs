using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class ddfdfdfdf : IMessage
    {
    }
}