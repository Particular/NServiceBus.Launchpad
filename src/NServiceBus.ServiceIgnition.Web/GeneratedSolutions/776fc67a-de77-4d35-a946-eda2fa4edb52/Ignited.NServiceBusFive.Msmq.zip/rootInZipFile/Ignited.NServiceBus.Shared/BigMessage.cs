using NServiceBus;

namespace Ignited.NServiceBus.Shared
{
    public class BigMessage : IMessage
    {
    }
}